Pull command: docker pull cutetn/teamdns
Run command: docker run -it -p 4567:4567 cutetn/teamdns
